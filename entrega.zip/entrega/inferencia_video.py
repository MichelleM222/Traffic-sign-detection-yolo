from ultralytics import YOLO
import cv2

# Modelo entrenado
model = YOLO("runs/detect/train-4/weights/best.pt")

# Video del profesor
video_path = "video_profesor.mp4"

cap = cv2.VideoCapture(video_path)

while True:
    ret, frame = cap.read()

    if not ret:
        break

    results = model(frame, conf=0.4)

    annotated_frame = results[0].plot()

    cv2.imshow("Deteccion de Senales", annotated_frame)

    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

cap.release()
cv2.destroyAllWindows()
