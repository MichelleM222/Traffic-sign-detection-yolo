import pandas as pd
import shutil
import random
from pathlib import Path
from PIL import Image

# Leer CSV
df = pd.read_csv("senales_filtradas.csv")

# Carpeta donde están las imágenes originales
imagenes_origen = Path("../../TrainIJCNN2013/TrainIJCNN2013")

# Carpetas YOLO
train_img = Path("dataset_yolo/images/train")
val_img = Path("dataset_yolo/images/val")
train_lbl = Path("dataset_yolo/labels/train")
val_lbl = Path("dataset_yolo/labels/val")

# Agrupar anotaciones por imagen
grupos = df.groupby("imagen")

imagenes = list(grupos.groups.keys())
random.shuffle(imagenes)

split = int(len(imagenes) * 0.8)

train_set = set(imagenes[:split])
val_set = set(imagenes[split:])

for imagen, grupo in grupos:

    ruta_imagen = imagenes_origen / imagen

    if not ruta_imagen.exists():
        print(f"No existe: {imagen}")
        continue

    img = Image.open(ruta_imagen)
    ancho_img, alto_img = img.size

    if imagen in train_set:
        carpeta_img = train_img
        carpeta_lbl = train_lbl
    else:
        carpeta_img = val_img
        carpeta_lbl = val_lbl

    shutil.copy(ruta_imagen, carpeta_img / imagen)

    nombre_txt = Path(imagen).stem + ".txt"

    with open(carpeta_lbl / nombre_txt, "w") as f:

        for _, fila in grupo.iterrows():

            clase = 0 if fila["clase"] == "speed_limit_30" else 1

            cx = fila["centro_x"] / ancho_img
            cy = fila["centro_y"] / alto_img
            w = fila["ancho"] / ancho_img
            h = fila["alto"] / alto_img

            f.write(
                f"{clase} {cx} {cy} {w} {h}\n"
            )

print("Dataset YOLO generado correctamente")