from PIL import Image
from pathlib import Path

origen = Path("dataset_yolo/images")
destino = Path("imagenes_png")

destino.mkdir(exist_ok=True)

for carpeta in ["train", "val"]:
    (destino / carpeta).mkdir(exist_ok=True)

    for img in (origen / carpeta).glob("*.ppm"):
        imagen = Image.open(img)
        nuevo_nombre = img.stem + ".png"
        imagen.save(destino / carpeta / nuevo_nombre)

print("Conversión terminada")